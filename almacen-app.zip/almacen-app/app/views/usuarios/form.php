<?php $esEdicion = $usuario !== null; ?>
<section class="tarjeta tarjeta--angosta">
    <h1><?= $esEdicion ? 'Editar usuario' : 'Nuevo usuario' ?></h1>
    <form action="<?= BASE_URL ?>/<?= $esEdicion ? 'usuarios/actualizar/' . $usuario['id_usuario'] : 'usuarios/guardar' ?>" method="POST" class="formulario">
        <input type="hidden" name="csrf_token" value="<?= $token ?>">

        <div class="campo campo--doble">
            <div>
                <label for="nombre">Nombre</label>
                <input type="text" name="nombre" id="nombre" required value="<?= htmlspecialchars($usuario['nombre'] ?? '') ?>">
            </div>
            <div>
                <label for="apellido">Apellido</label>
                <input type="text" name="apellido" id="apellido" required value="<?= htmlspecialchars($usuario['apellido'] ?? '') ?>">
            </div>
        </div>

        <div class="campo">
            <label for="email">Correo electrónico</label>
            <input type="email" name="email" id="email" required value="<?= htmlspecialchars($usuario['email'] ?? '') ?>">
        </div>

        <div class="campo">
            <label for="rol">Rol</label>
            <select name="rol" id="rol">
                <?php foreach (['administrador', 'almacenista', 'vendedor'] as $rol): ?>
                    <option value="<?= $rol ?>" <?= ($usuario['rol'] ?? '') === $rol ? 'selected' : '' ?>>
                        <?= ucfirst($rol) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="campo">
            <label for="password"><?= $esEdicion ? 'Nueva contraseña (dejar en blanco para no cambiar)' : 'Contraseña' ?></label>
            <input type="password" name="password" id="password" <?= $esEdicion ? '' : 'required' ?>>
        </div>

        <button type="submit" class="boton boton--primario"><?= $esEdicion ? 'Guardar cambios' : 'Crear usuario' ?></button>
        <a href="<?= BASE_URL ?>/usuarios" class="boton boton--secundario">Cancelar</a>
    </form>
</section>
