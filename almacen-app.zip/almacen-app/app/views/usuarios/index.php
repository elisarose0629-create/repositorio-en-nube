<section class="tarjeta">
    <div class="tarjeta__encabezado">
        <h1>Usuarios internos</h1>
        <a href="<?= BASE_URL ?>/usuarios-crear" class="boton boton--primario">+ Nuevo usuario</a>
    </div>

    <div class="tabla-envoltura">
        <table class="tabla">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Rol</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($usuarios)): ?>
                <tr><td colspan="5" class="texto-centrado">No hay usuarios registrados.</td></tr>
            <?php endif; ?>
            <?php foreach ($usuarios as $usuario): ?>
                <tr>
                    <td><?= htmlspecialchars($usuario['nombre'] . ' ' . $usuario['apellido']) ?></td>
                    <td><?= htmlspecialchars($usuario['email']) ?></td>
                    <td><span class="etiqueta"><?= htmlspecialchars(ucfirst($usuario['rol'])) ?></span></td>
                    <td><?= $usuario['estado'] ? 'Activo' : 'Inactivo' ?></td>
                    <td class="acciones">
                        <a href="<?= BASE_URL ?>/usuarios/editar/<?= $usuario['id_usuario'] ?>" class="boton boton--pequeno">Editar</a>
                        <form action="<?= BASE_URL ?>/usuarios/eliminar/<?= $usuario['id_usuario'] ?>" method="POST" onsubmit="return confirm('¿Eliminar este usuario?');">
                            <input type="hidden" name="csrf_token" value="<?= \Seguridad::generarTokenCsrf() ?>">
                            <button type="submit" class="boton boton--peligro boton--pequeno">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
