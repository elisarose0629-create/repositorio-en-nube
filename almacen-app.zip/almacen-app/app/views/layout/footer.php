</main>
<footer class="pie">
    <div class="contenedor">
        <p>&copy; <?= date('Y') ?> AlmacénApp — Sistema de Gestión de Almacén. Todos los derechos reservados.</p>
    </div>
</footer>
<script src="<?= BASE_URL ?>/js/script.js"></script>
</body>
</html>
