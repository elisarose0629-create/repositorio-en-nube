<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestión de Almacén</title>
    <link rel="icon" type="image/png" href="<?= BASE_URL ?>/img/favicon.png">
    <link rel="stylesheet" href="<?= BASE_URL ?>/css/style.css">
</head>
<body>
<header class="cabecera">
    <div class="contenedor cabecera__interior">
        <a href="<?= BASE_URL ?>/<?= empty($_SESSION['autenticado']) ? 'login' : ($_SESSION['tipo_cuenta'] === 'usuario' ? 'productos' : 'tienda') ?>" class="cabecera__logo">
            📦 Almacén<span>App</span>
        </a>
        <?php if (!empty($_SESSION['autenticado'])): ?>
        <nav class="cabecera__nav">
            <?php if ($_SESSION['tipo_cuenta'] === 'usuario'): ?>
                <a href="<?= BASE_URL ?>/productos">Productos</a>
                <a href="<?= BASE_URL ?>/clientes">Clientes</a>
                <?php if (($_SESSION['rol'] ?? '') === 'administrador'): ?>
                    <a href="<?= BASE_URL ?>/usuarios">Usuarios</a>
                <?php endif; ?>
            <?php endif; ?>
            <span class="cabecera__usuario">👤 <?= htmlspecialchars($_SESSION['nombre'] ?? '') ?></span>
            <a href="<?= BASE_URL ?>/logout" class="boton boton--secundario">Salir</a>
        </nav>
        <?php endif; ?>
    </div>
</header>
<main class="contenedor principal">
    <?php if (!empty($_SESSION['mensaje'])): ?>
        <div class="alerta alerta--<?= $_SESSION['mensaje']['tipo'] === 'exito' ? 'exito' : 'error' ?>">
            <?= htmlspecialchars($_SESSION['mensaje']['texto']) ?>
        </div>
        <?php unset($_SESSION['mensaje']); ?>
    <?php endif; ?>
