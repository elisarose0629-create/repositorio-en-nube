<section class="tarjeta">
    <div class="tarjeta__encabezado">
        <h1>Mis pedidos</h1>
        <a href="<?= BASE_URL ?>/tienda" class="boton boton--secundario">Volver al catálogo</a>
    </div>

    <?php if (empty($pedidos)): ?>
        <p>Aún no has realizado ninguna compra.</p>
    <?php endif; ?>

    <?php foreach ($pedidos as $pedido): ?>
        <div class="tarjeta-pedido">
            <div class="tarjeta-pedido__encabezado">
                <strong>Pedido #<?= $pedido['id_pedido'] ?></strong>
                <span><?= date('d/m/Y H:i', strtotime($pedido['fecha_pedido'])) ?></span>
                <span class="etiqueta etiqueta--ok"><?= ucfirst($pedido['estado']) ?></span>
            </div>
            <div class="tabla-envoltura">
                <table class="tabla">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Precio unitario</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pedido['items'] as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['producto']) ?></td>
                            <td><?= (int) $item['cantidad'] ?></td>
                            <td>$<?= number_format((float) $item['precio_unitario'], 2) ?></td>
                            <td>$<?= number_format((float) $item['subtotal'], 2) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <p class="tarjeta-pedido__total">Total: <strong>$<?= number_format((float) $pedido['total'], 2) ?></strong></p>
        </div>
    <?php endforeach; ?>
</section>
