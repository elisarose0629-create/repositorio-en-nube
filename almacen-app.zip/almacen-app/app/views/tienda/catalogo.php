<section class="tarjeta">
    <div class="tarjeta__encabezado">
        <h1>Catálogo de productos</h1>
        <div class="tarjeta__acciones">
            <a href="<?= BASE_URL ?>/tienda/pedidos" class="boton boton--secundario">Mis pedidos</a>
            <a href="<?= BASE_URL ?>/clientes/editar/<?= $_SESSION['id_cliente'] ?>" class="boton boton--secundario">Mis datos</a>
        </div>
    </div>

    <div class="rejilla-productos">
        <?php if (empty($productos)): ?>
            <p>No hay productos disponibles en este momento.</p>
        <?php endif; ?>
        <?php foreach ($productos as $producto): ?>
            <article class="tarjeta-producto">
                <h3><?= htmlspecialchars($producto['nombre']) ?></h3>
                <p class="tarjeta-producto__categoria"><?= htmlspecialchars($producto['categoria'] ?? 'General') ?></p>
                <p class="tarjeta-producto__precio">$<?= number_format((float) $producto['precio'], 2) ?></p>
                <p class="tarjeta-producto__stock">
                    <?= $producto['stock'] > 0 ? 'Disponible (' . (int) $producto['stock'] . ')' : 'Agotado' ?>
                </p>

                <?php if ($producto['stock'] > 0): ?>
                <form action="<?= BASE_URL ?>/tienda/comprar/<?= $producto['id_producto'] ?>" method="POST" class="formulario-compra">
                    <input type="hidden" name="csrf_token" value="<?= $token ?>">
                    <input type="number" name="cantidad" value="1" min="1" max="<?= (int) $producto['stock'] ?>" required>
                    <button type="submit" class="boton boton--primario boton--pequeno">Comprar</button>
                </form>
                <?php endif; ?>
            </article>
        <?php endforeach; ?>
    </div>
</section>
