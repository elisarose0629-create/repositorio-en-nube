<section class="tarjeta">
    <div class="tarjeta__encabezado">
        <h1>Clientes registrados</h1>
    </div>

    <div class="tabla-envoltura">
        <table class="tabla">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Teléfono</th>
                    <th>Dirección</th>
                    <th>Registrado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($clientes)): ?>
                <tr><td colspan="6" class="texto-centrado">No hay clientes registrados.</td></tr>
            <?php endif; ?>
            <?php foreach ($clientes as $cliente): ?>
                <tr>
                    <td><?= htmlspecialchars($cliente['nombre'] . ' ' . $cliente['apellido']) ?></td>
                    <td><?= htmlspecialchars($cliente['email']) ?></td>
                    <td><?= htmlspecialchars($cliente['telefono'] ?? '—') ?></td>
                    <td><?= htmlspecialchars($cliente['direccion'] ?? '—') ?></td>
                    <td><?= htmlspecialchars(date('d/m/Y', strtotime($cliente['fecha_registro']))) ?></td>
                    <td class="acciones">
                        <a href="<?= BASE_URL ?>/clientes/editar/<?= $cliente['id_cliente'] ?>" class="boton boton--pequeno">Editar</a>
                        <form action="<?= BASE_URL ?>/clientes/eliminar/<?= $cliente['id_cliente'] ?>" method="POST" onsubmit="return confirm('¿Eliminar este cliente?');">
                            <input type="hidden" name="csrf_token" value="<?= \Seguridad::generarTokenCsrf() ?>">
                            <button type="submit" class="boton boton--peligro boton--pequeno">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
