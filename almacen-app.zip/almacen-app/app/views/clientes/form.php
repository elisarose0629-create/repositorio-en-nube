<section class="tarjeta tarjeta--angosta">
    <h1>Editar cliente</h1>
    <form action="<?= BASE_URL ?>/clientes/actualizar/<?= $cliente['id_cliente'] ?>" method="POST" class="formulario">
        <input type="hidden" name="csrf_token" value="<?= $token ?>">

        <div class="campo campo--doble">
            <div>
                <label for="nombre">Nombre</label>
                <input type="text" name="nombre" id="nombre" required value="<?= htmlspecialchars($cliente['nombre']) ?>">
            </div>
            <div>
                <label for="apellido">Apellido</label>
                <input type="text" name="apellido" id="apellido" required value="<?= htmlspecialchars($cliente['apellido']) ?>">
            </div>
        </div>

        <div class="campo">
            <label for="email">Correo electrónico</label>
            <input type="email" name="email" id="email" required value="<?= htmlspecialchars($cliente['email']) ?>">
        </div>

        <div class="campo">
            <label for="telefono">Teléfono</label>
            <input type="tel" name="telefono" id="telefono" value="<?= htmlspecialchars($cliente['telefono'] ?? '') ?>">
        </div>

        <div class="campo">
            <label for="direccion">Dirección</label>
            <input type="text" name="direccion" id="direccion" value="<?= htmlspecialchars($cliente['direccion'] ?? '') ?>">
        </div>

        <button type="submit" class="boton boton--primario">Guardar cambios</button>
        <a href="<?= BASE_URL ?>/clientes" class="boton boton--secundario">Cancelar</a>
    </form>
</section>
