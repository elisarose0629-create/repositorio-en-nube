<section class="tarjeta tarjeta--angosta">
    <h1>Iniciar sesión</h1>
    <form action="<?= BASE_URL ?>/auth-login" method="POST" class="formulario" novalidate>
        <input type="hidden" name="csrf_token" value="<?= $token ?>">

        <div class="campo">
            <label for="tipo_cuenta">Tipo de cuenta</label>
            <select name="tipo_cuenta" id="tipo_cuenta">
                <option value="cliente">Cliente (tienda)</option>
                <option value="usuario">Personal interno</option>
            </select>
        </div>

        <div class="campo">
            <label for="email">Correo electrónico</label>
            <input type="email" name="email" id="email" required autocomplete="username">
        </div>

        <div class="campo">
            <label for="password">Contraseña</label>
            <input type="password" name="password" id="password" required autocomplete="current-password">
        </div>

        <button type="submit" class="boton boton--primario">Ingresar</button>
    </form>
    <p class="texto-ayuda">¿No tiene una cuenta? <a href="<?= BASE_URL ?>/registro">Regístrese aquí</a></p>
</section>
