<section class="tarjeta tarjeta--angosta">
    <h1>Crear cuenta</h1>
    <form action="<?= BASE_URL ?>/auth-registro" method="POST" class="formulario" novalidate>
        <input type="hidden" name="csrf_token" value="<?= $token ?>">

        <div class="campo campo--doble">
            <div>
                <label for="nombre">Nombre</label>
                <input type="text" name="nombre" id="nombre" required>
            </div>
            <div>
                <label for="apellido">Apellido</label>
                <input type="text" name="apellido" id="apellido" required>
            </div>
        </div>

        <div class="campo">
            <label for="email">Correo electrónico</label>
            <input type="email" name="email" id="email" required autocomplete="username">
        </div>

        <div class="campo">
            <label for="telefono">Teléfono</label>
            <input type="tel" name="telefono" id="telefono">
        </div>

        <div class="campo">
            <label for="direccion">Dirección</label>
            <input type="text" name="direccion" id="direccion">
        </div>

        <div class="campo campo--doble">
            <div>
                <label for="password">Contraseña</label>
                <input type="password" name="password" id="password" required autocomplete="new-password">
            </div>
            <div>
                <label for="confirmar_password">Confirmar contraseña</label>
                <input type="password" name="confirmar_password" id="confirmar_password" required autocomplete="new-password">
            </div>
        </div>
        <p class="texto-ayuda">Mínimo 8 caracteres, con al menos una mayúscula, una minúscula y un número.</p>

        <button type="submit" class="boton boton--primario">Registrarme</button>
    </form>
    <p class="texto-ayuda">¿Ya tiene una cuenta? <a href="<?= BASE_URL ?>/login">Inicie sesión aquí</a></p>
</section>
