<?php $esEdicion = $producto !== null; ?>
<section class="tarjeta tarjeta--angosta">
    <h1><?= $esEdicion ? 'Editar producto' : 'Nuevo producto' ?></h1>
    <form action="<?= BASE_URL ?>/<?= $esEdicion ? 'productos/actualizar/' . $producto['id_producto'] : 'productos/guardar' ?>" method="POST" class="formulario">
        <input type="hidden" name="csrf_token" value="<?= $token ?>">

        <div class="campo">
            <label for="codigo_sku">Código SKU</label>
            <input type="text" name="codigo_sku" id="codigo_sku" required
                   value="<?= htmlspecialchars($producto['codigo_sku'] ?? '') ?>">
        </div>

        <div class="campo">
            <label for="nombre">Nombre del producto</label>
            <input type="text" name="nombre" id="nombre" required
                   value="<?= htmlspecialchars($producto['nombre'] ?? '') ?>">
        </div>

        <div class="campo">
            <label for="descripcion">Descripción</label>
            <textarea name="descripcion" id="descripcion" rows="3"><?= htmlspecialchars($producto['descripcion'] ?? '') ?></textarea>
        </div>

        <div class="campo">
            <label for="id_categoria">Categoría</label>
            <select name="id_categoria" id="id_categoria">
                <option value="">-- Sin categoría --</option>
                <?php foreach ($categorias as $categoria): ?>
                    <option value="<?= $categoria['id_categoria'] ?>"
                        <?= isset($producto['id_categoria']) && $producto['id_categoria'] == $categoria['id_categoria'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($categoria['nombre']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="campo campo--doble">
            <div>
                <label for="precio">Precio ($)</label>
                <input type="number" step="0.01" min="0" name="precio" id="precio" required
                       value="<?= htmlspecialchars($producto['precio'] ?? '0') ?>">
            </div>
            <div>
                <label for="stock">Stock actual</label>
                <input type="number" min="0" name="stock" id="stock" required
                       value="<?= htmlspecialchars($producto['stock'] ?? '0') ?>">
            </div>
        </div>

        <div class="campo">
            <label for="stock_minimo">Stock mínimo (alerta)</label>
            <input type="number" min="0" name="stock_minimo" id="stock_minimo"
                   value="<?= htmlspecialchars($producto['stock_minimo'] ?? '5') ?>">
        </div>

        <button type="submit" class="boton boton--primario"><?= $esEdicion ? 'Guardar cambios' : 'Crear producto' ?></button>
        <a href="<?= BASE_URL ?>/productos" class="boton boton--secundario">Cancelar</a>
    </form>
</section>
