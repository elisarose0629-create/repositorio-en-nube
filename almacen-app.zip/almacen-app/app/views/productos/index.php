<section class="tarjeta">
    <div class="tarjeta__encabezado">
        <h1>Productos del almacén</h1>
        <a href="<?= BASE_URL ?>/productos-crear" class="boton boton--primario">+ Nuevo producto</a>
    </div>

    <div class="tabla-envoltura">
        <table class="tabla">
            <thead>
                <tr>
                    <th>SKU</th>
                    <th>Nombre</th>
                    <th>Categoría</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($productos)): ?>
                <tr><td colspan="6" class="texto-centrado">No hay productos registrados.</td></tr>
            <?php endif; ?>
            <?php foreach ($productos as $producto): ?>
                <tr>
                    <td><?= htmlspecialchars($producto['codigo_sku']) ?></td>
                    <td><?= htmlspecialchars($producto['nombre']) ?></td>
                    <td><?= htmlspecialchars($producto['categoria'] ?? 'Sin categoría') ?></td>
                    <td>$<?= number_format((float) $producto['precio'], 2) ?></td>
                    <td>
                        <span class="etiqueta <?= $producto['stock'] <= $producto['stock_minimo'] ? 'etiqueta--alerta' : 'etiqueta--ok' ?>">
                            <?= (int) $producto['stock'] ?>
                        </span>
                    </td>
                    <td class="acciones">
                        <a href="<?= BASE_URL ?>/productos/editar/<?= $producto['id_producto'] ?>" class="boton boton--pequeno">Editar</a>
                        <form action="<?= BASE_URL ?>/productos/eliminar/<?= $producto['id_producto'] ?>" method="POST" onsubmit="return confirm('¿Eliminar este producto?');">
                            <input type="hidden" name="csrf_token" value="<?= \Seguridad::generarTokenCsrf() ?>">
                            <button type="submit" class="boton boton--peligro boton--pequeno">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>
