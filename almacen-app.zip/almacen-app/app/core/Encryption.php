<?php


class Encryption
{
    private const METODO = 'aes-256-cbc';

    public static function cifrar(string $textoPlano): string
    {
        $longitudIv = openssl_cipher_iv_length(self::METODO);
        $iv = openssl_random_pseudo_bytes($longitudIv);

        $textoCifrado = openssl_encrypt(
            $textoPlano,
            self::METODO,
            self::obtenerClave(),
            OPENSSL_RAW_DATA,
            $iv
        );

       
        return base64_encode($iv . $textoCifrado);
    }

    public static function descifrar(?string $textoCifradoBase64): ?string
    {
        if (empty($textoCifradoBase64)) {
            return null;
        }

        $datos = base64_decode($textoCifradoBase64);
        $longitudIv = openssl_cipher_iv_length(self::METODO);

        $iv = substr($datos, 0, $longitudIv);
        $textoCifrado = substr($datos, $longitudIv);

        $resultado = openssl_decrypt(
            $textoCifrado,
            self::METODO,
            self::obtenerClave(),
            OPENSSL_RAW_DATA,
            $iv
        );

        return $resultado === false ? null : $resultado;
    }

    private static function obtenerClave(): string
    {
        
        return hash('sha256', APP_ENCRYPTION_KEY, true);
    }
}
