<?php

abstract class Controller
{
    protected function renderizarVista(string $rutaVista, array $datos = []): void
    {
        extract($datos);
        $rutaCompleta = APP_ROOT . '/app/views/' . $rutaVista . '.php';

        if (!file_exists($rutaCompleta)) {
            throw new RuntimeException("Vista no encontrada: {$rutaVista}");
        }

        require APP_ROOT . '/app/views/layout/header.php';
        require $rutaCompleta;
        require APP_ROOT . '/app/views/layout/footer.php';
    }

    protected function redireccionar(string $ruta): void
    {
        header('Location: ' . BASE_URL . '/' . ltrim($ruta, '/'));
        exit;
    }

    protected function esPeticionPost(): bool
    {
        return $_SERVER['REQUEST_METHOD'] === 'POST';
    }

    protected function guardarMensaje(string $tipo, string $texto): void
    {
        $_SESSION['mensaje'] = ['tipo' => $tipo, 'texto' => $texto];
    }
}
