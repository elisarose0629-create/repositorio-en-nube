<?php


class Seguridad
{
    public static function generarTokenCsrf(): string
    {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    public static function validarTokenCsrf(?string $tokenRecibido): bool
    {
        if (empty($tokenRecibido) || empty($_SESSION['csrf_token'])) {
            return false;
        }
        return hash_equals($_SESSION['csrf_token'], $tokenRecibido);
    }

    public static function limpiarCadena(?string $valor): string
    {
        $valor = trim($valor ?? '');
        $valor = strip_tags($valor);
        return htmlspecialchars($valor, ENT_QUOTES, 'UTF-8');
    }

    public static function validarEmail(string $email): bool
    {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }

    public static function passwordEsSegura(string $password): bool
    {
        
        return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/', $password) === 1;
    }
}
