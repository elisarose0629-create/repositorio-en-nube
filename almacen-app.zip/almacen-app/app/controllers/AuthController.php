<?php

require_once APP_ROOT . '/app/models/Usuario.php';
require_once APP_ROOT . '/app/models/Cliente.php';
require_once APP_ROOT . '/app/core/Seguridad.php';

class AuthController extends Controller
{
    private Usuario $modeloUsuario;
    private Cliente $modeloCliente;

    public function __construct()
    {
        $this->modeloUsuario = new Usuario();
        $this->modeloCliente = new Cliente();
    }

    public function mostrarLogin(): void
    {
        $token = Seguridad::generarTokenCsrf();
        $this->renderizarVista('auth/login', ['token' => $token]);
    }

    public function procesarLogin(): void
    {
        if (!$this->esPeticionPost()) {
            $this->redireccionar('login');
        }

        if (!Seguridad::validarTokenCsrf($_POST['csrf_token'] ?? null)) {
            $this->guardarMensaje('error', 'Token de seguridad inválido. Intente nuevamente.');
            $this->redireccionar('login');
        }

        $email = Seguridad::limpiarCadena($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $tipoCuenta = $_POST['tipo_cuenta'] ?? 'cliente';

        if (!Seguridad::validarEmail($email) || empty($password)) {
            $this->guardarMensaje('error', 'Correo o contraseña inválidos.');
            $this->redireccionar('login');
        }

        $modelo = $tipoCuenta === 'usuario' ? $this->modeloUsuario : $this->modeloCliente;
        $cuenta = $modelo->buscarPorEmail($email);

        if (!$cuenta) {
            $this->guardarMensaje('error', 'Credenciales incorrectas.');
            $this->redireccionar('login');
        }

        // Verificar bloqueo por intentos fallidos
        if (!empty($cuenta['bloqueado_hasta']) && strtotime($cuenta['bloqueado_hasta']) > time()) {
            $this->guardarMensaje('error', 'Cuenta bloqueada temporalmente por múltiples intentos fallidos.');
            $this->redireccionar('login');
        }

        if (!password_verify($password, $cuenta['password_hash'])) {
            $idCampo = $tipoCuenta === 'usuario' ? 'id_usuario' : 'id_cliente';
            $modelo->registrarIntentoFallido((int) $cuenta[$idCampo]);

            if (($cuenta['intentos_fallidos'] + 1) >= MAX_INTENTOS_LOGIN && $tipoCuenta === 'usuario') {
                $this->modeloUsuario->bloquearCuenta((int) $cuenta[$idCampo], MINUTOS_BLOQUEO);
            }

            $this->guardarMensaje('error', 'Credenciales incorrectas.');
            $this->redireccionar('login');
        }

        // Login correcto: reiniciar contador de intentos y regenerar el id de sesión
        session_regenerate_id(true);
        $modelo->reiniciarIntentosFallidos((int) $cuenta[$tipoCuenta === 'usuario' ? 'id_usuario' : 'id_cliente']);

        $_SESSION['autenticado'] = true;
        $_SESSION['tipo_cuenta'] = $tipoCuenta;
        $_SESSION['nombre'] = $cuenta['nombre'] . ' ' . $cuenta['apellido'];
        $_SESSION['email'] = $cuenta['email'];
        $_SESSION['ultima_actividad'] = time();

        if ($tipoCuenta === 'usuario') {
            $_SESSION['id_usuario'] = $cuenta['id_usuario'];
            $_SESSION['rol'] = $cuenta['rol'];
            $this->redireccionar('productos');
        }

        $_SESSION['id_cliente'] = $cuenta['id_cliente'];
        $this->redireccionar('tienda');
    }

    public function mostrarRegistro(): void
    {
        $token = Seguridad::generarTokenCsrf();
        $this->renderizarVista('auth/registro', ['token' => $token]);
    }

    public function procesarRegistro(): void
    {
        if (!$this->esPeticionPost()) {
            $this->redireccionar('registro');
        }

        if (!Seguridad::validarTokenCsrf($_POST['csrf_token'] ?? null)) {
            $this->guardarMensaje('error', 'Token de seguridad inválido. Intente nuevamente.');
            $this->redireccionar('registro');
        }

        $datos = [
            'nombre'    => Seguridad::limpiarCadena($_POST['nombre'] ?? ''),
            'apellido'  => Seguridad::limpiarCadena($_POST['apellido'] ?? ''),
            'email'     => Seguridad::limpiarCadena($_POST['email'] ?? ''),
            'telefono'  => Seguridad::limpiarCadena($_POST['telefono'] ?? ''),
            'direccion' => Seguridad::limpiarCadena($_POST['direccion'] ?? ''),
            'password'  => $_POST['password'] ?? '',
        ];

        $confirmacion = $_POST['confirmar_password'] ?? '';

        if (!Seguridad::validarEmail($datos['email'])) {
            $this->guardarMensaje('error', 'El correo electrónico no es válido.');
            $this->redireccionar('registro');
        }

        if ($datos['password'] !== $confirmacion) {
            $this->guardarMensaje('error', 'Las contraseñas no coinciden.');
            $this->redireccionar('registro');
        }

        if (!Seguridad::passwordEsSegura($datos['password'])) {
            $this->guardarMensaje('error', 'La contraseña debe tener mínimo 8 caracteres, una mayúscula, una minúscula y un número.');
            $this->redireccionar('registro');
        }

        if ($this->modeloCliente->buscarPorEmail($datos['email'])) {
            $this->guardarMensaje('error', 'Ya existe una cuenta registrada con ese correo.');
            $this->redireccionar('registro');
        }

        if ($this->modeloCliente->crear($datos)) {
            $this->guardarMensaje('exito', 'Registro exitoso. Ahora puede iniciar sesión.');
            $this->redireccionar('login');
        }

        $this->guardarMensaje('error', 'Ocurrió un error al registrar la cuenta.');
        $this->redireccionar('registro');
    }

    public function cerrarSesion(): void
    {
        $_SESSION = [];
        session_destroy();
        $this->redireccionar('login');
    }
}
