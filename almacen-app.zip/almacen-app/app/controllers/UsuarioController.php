<?php

require_once APP_ROOT . '/app/models/Usuario.php';
require_once APP_ROOT . '/app/core/Seguridad.php';

class UsuarioController extends Controller
{
    private Usuario $modelo;

    public function __construct()
    {
        $this->verificarAcceso();
        $this->modelo = new Usuario();
    }

    private function verificarAcceso(): void
    {
        if (empty($_SESSION['autenticado']) || $_SESSION['tipo_cuenta'] !== 'usuario') {
            $this->redireccionar('login');
        }
        if (($_SESSION['rol'] ?? '') !== 'administrador') {
            $this->guardarMensaje('error', 'No tiene permisos para acceder a esta sección.');
            $this->redireccionar('productos');
        }
    }

    public function listar(): void
    {
        $usuarios = $this->modelo->obtenerTodos();
        $this->renderizarVista('usuarios/index', ['usuarios' => $usuarios]);
    }

    public function mostrarFormularioCrear(): void
    {
        $token = Seguridad::generarTokenCsrf();
        $this->renderizarVista('usuarios/form', ['usuario' => null, 'token' => $token]);
    }

    public function crear(): void
    {
        if (!$this->esPeticionPost() || !Seguridad::validarTokenCsrf($_POST['csrf_token'] ?? null)) {
            $this->redireccionar('usuarios');
        }

        $datos = $this->obtenerDatosFormulario();

        if (!Seguridad::passwordEsSegura($datos['password'] ?? '')) {
            $this->guardarMensaje('error', 'La contraseña no cumple los requisitos mínimos de seguridad.');
            $this->redireccionar('usuarios/crear');
        }

        if ($this->modelo->buscarPorEmail($datos['email'])) {
            $this->guardarMensaje('error', 'El correo ya está registrado.');
            $this->redireccionar('usuarios/crear');
        }

        $this->modelo->crear($datos);
        $this->guardarMensaje('exito', 'Usuario creado correctamente.');
        $this->redireccionar('usuarios');
    }

    public function mostrarFormularioEditar(int $id): void
    {
        $usuario = $this->modelo->buscarPorId($id);
        if (!$usuario) {
            $this->guardarMensaje('error', 'Usuario no encontrado.');
            $this->redireccionar('usuarios');
        }
        $token = Seguridad::generarTokenCsrf();
        $this->renderizarVista('usuarios/form', ['usuario' => $usuario, 'token' => $token]);
    }

    public function actualizar(int $id): void
    {
        if (!$this->esPeticionPost() || !Seguridad::validarTokenCsrf($_POST['csrf_token'] ?? null)) {
            $this->redireccionar('usuarios');
        }

        $datos = $this->obtenerDatosFormulario();
        $this->modelo->actualizar($id, $datos);

        if (!empty($datos['password'])) {
            $this->modelo->cambiarPassword($id, $datos['password']);
        }

        $this->guardarMensaje('exito', 'Usuario actualizado correctamente.');
        $this->redireccionar('usuarios');
    }

    public function eliminar(int $id): void
    {
        if (!Seguridad::validarTokenCsrf($_POST['csrf_token'] ?? null)) {
            $this->redireccionar('usuarios');
        }
        $this->modelo->eliminar($id);
        $this->guardarMensaje('exito', 'Usuario eliminado correctamente.');
        $this->redireccionar('usuarios');
    }

    private function obtenerDatosFormulario(): array
    {
        return [
            'nombre'   => Seguridad::limpiarCadena($_POST['nombre'] ?? ''),
            'apellido' => Seguridad::limpiarCadena($_POST['apellido'] ?? ''),
            'email'    => Seguridad::limpiarCadena($_POST['email'] ?? ''),
            'rol'      => Seguridad::limpiarCadena($_POST['rol'] ?? 'almacenista'),
            'password' => $_POST['password'] ?? '',
        ];
    }
}
