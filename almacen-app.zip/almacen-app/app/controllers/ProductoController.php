<?php

require_once APP_ROOT . '/app/models/Producto.php';
require_once APP_ROOT . '/app/core/Seguridad.php';


class ProductoController extends Controller
{
    private Producto $modelo;

    public function __construct()
    {
        if (empty($_SESSION['autenticado']) || $_SESSION['tipo_cuenta'] !== 'usuario') {
            $this->redireccionar('login');
        }
        $this->modelo = new Producto();
    }

    public function listar(): void
    {
        $productos = $this->modelo->obtenerTodos();
        $this->renderizarVista('productos/index', ['productos' => $productos]);
    }

    public function mostrarFormularioCrear(): void
    {
        $categorias = $this->modelo->obtenerCategorias();
        $token = Seguridad::generarTokenCsrf();
        $this->renderizarVista('productos/form', [
            'producto'   => null,
            'categorias' => $categorias,
            'token'      => $token,
        ]);
    }

    public function crear(): void
    {
        if (!$this->esPeticionPost() || !Seguridad::validarTokenCsrf($_POST['csrf_token'] ?? null)) {
            $this->redireccionar('productos');
        }

        $datos = $this->obtenerDatosFormulario();
        $this->modelo->crear($datos, $_SESSION['id_usuario'] ?? null);

        $this->guardarMensaje('exito', 'Producto creado correctamente.');
        $this->redireccionar('productos');
    }

    public function mostrarFormularioEditar(int $id): void
    {
        $producto = $this->modelo->buscarPorId($id);
        if (!$producto) {
            $this->guardarMensaje('error', 'Producto no encontrado.');
            $this->redireccionar('productos');
        }

        $categorias = $this->modelo->obtenerCategorias();
        $token = Seguridad::generarTokenCsrf();
        $this->renderizarVista('productos/form', [
            'producto'   => $producto,
            'categorias' => $categorias,
            'token'      => $token,
        ]);
    }

    public function actualizar(int $id): void
    {
        if (!$this->esPeticionPost() || !Seguridad::validarTokenCsrf($_POST['csrf_token'] ?? null)) {
            $this->redireccionar('productos');
        }

        $datos = $this->obtenerDatosFormulario();
        $this->modelo->actualizar($id, $datos);

        $this->guardarMensaje('exito', 'Producto actualizado correctamente.');
        $this->redireccionar('productos');
    }

    public function eliminar(int $id): void
    {
        if (!Seguridad::validarTokenCsrf($_POST['csrf_token'] ?? null)) {
            $this->redireccionar('productos');
        }
        $this->modelo->eliminar($id);
        $this->guardarMensaje('exito', 'Producto eliminado correctamente.');
        $this->redireccionar('productos');
    }

    private function obtenerDatosFormulario(): array
    {
        return [
            'codigo_sku'   => Seguridad::limpiarCadena($_POST['codigo_sku'] ?? ''),
            'nombre'       => Seguridad::limpiarCadena($_POST['nombre'] ?? ''),
            'descripcion'  => Seguridad::limpiarCadena($_POST['descripcion'] ?? ''),
            'id_categoria' => (int) ($_POST['id_categoria'] ?? 0),
            'precio'       => (float) ($_POST['precio'] ?? 0),
            'stock'        => (int) ($_POST['stock'] ?? 0),
            'stock_minimo' => (int) ($_POST['stock_minimo'] ?? 5),
        ];
    }
}
