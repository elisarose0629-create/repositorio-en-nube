<?php

require_once APP_ROOT . '/app/models/Cliente.php';
require_once APP_ROOT . '/app/core/Seguridad.php';

class ClienteController extends Controller
{
    private Cliente $modelo;

    public function __construct()
    {
        if (empty($_SESSION['autenticado'])) {
            $this->redireccionar('login');
        }
        $this->modelo = new Cliente();
    }

    public function listar(): void
    {
        $this->verificarEsPersonalInterno();
        $clientes = $this->modelo->obtenerTodos();
        $this->renderizarVista('clientes/index', ['clientes' => $clientes]);
    }

    public function mostrarFormularioEditar(int $id): void
    {
        $this->verificarPropietarioOInterno($id);
        $cliente = $this->modelo->buscarPorId($id);

        if (!$cliente) {
            $this->guardarMensaje('error', 'Cliente no encontrado.');
            $this->redireccionar('clientes');
        }

        $token = Seguridad::generarTokenCsrf();
        $this->renderizarVista('clientes/form', ['cliente' => $cliente, 'token' => $token]);
    }

    public function actualizar(int $id): void
    {
        $this->verificarPropietarioOInterno($id);

        if (!$this->esPeticionPost() || !Seguridad::validarTokenCsrf($_POST['csrf_token'] ?? null)) {
            $this->redireccionar('clientes');
        }

        $datos = [
            'nombre'    => Seguridad::limpiarCadena($_POST['nombre'] ?? ''),
            'apellido'  => Seguridad::limpiarCadena($_POST['apellido'] ?? ''),
            'email'     => Seguridad::limpiarCadena($_POST['email'] ?? ''),
            'telefono'  => Seguridad::limpiarCadena($_POST['telefono'] ?? ''),
            'direccion' => Seguridad::limpiarCadena($_POST['direccion'] ?? ''),
        ];

        $this->modelo->actualizar($id, $datos);
        $this->guardarMensaje('exito', 'Datos actualizados correctamente.');

        $destino = $_SESSION['tipo_cuenta'] === 'usuario' ? 'clientes' : 'tienda';
        $this->redireccionar($destino);
    }

    public function eliminar(int $id): void
    {
        $this->verificarEsPersonalInterno();

        if (!Seguridad::validarTokenCsrf($_POST['csrf_token'] ?? null)) {
            $this->redireccionar('clientes');
        }

        $this->modelo->eliminar($id);
        $this->guardarMensaje('exito', 'Cliente eliminado correctamente.');
        $this->redireccionar('clientes');
    }

    private function verificarEsPersonalInterno(): void
    {
        if (($_SESSION['tipo_cuenta'] ?? '') !== 'usuario') {
            $this->guardarMensaje('error', 'No tiene permisos para acceder a esta sección.');
            $this->redireccionar('tienda');
        }
    }

    private function verificarPropietarioOInterno(int $id): void
    {
        $esInterno = ($_SESSION['tipo_cuenta'] ?? '') === 'usuario';
        $esPropietario = ($_SESSION['tipo_cuenta'] ?? '') === 'cliente'
            && (int) ($_SESSION['id_cliente'] ?? 0) === $id;

        if (!$esInterno && !$esPropietario) {
            $this->guardarMensaje('error', 'No tiene permisos para esta acción.');
            $this->redireccionar('login');
        }
    }
}
