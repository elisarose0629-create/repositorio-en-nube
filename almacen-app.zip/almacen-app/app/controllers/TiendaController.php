<?php

require_once APP_ROOT . '/app/models/Producto.php';
require_once APP_ROOT . '/app/models/Pedido.php';
require_once APP_ROOT . '/app/core/Seguridad.php';


class TiendaController extends Controller
{
    private Producto $modeloProducto;
    private Pedido $modeloPedido;

    public function __construct()
    {
        if (empty($_SESSION['autenticado']) || $_SESSION['tipo_cuenta'] !== 'cliente') {
            $this->redireccionar('login');
        }
        $this->modeloProducto = new Producto();
        $this->modeloPedido = new Pedido();
    }

    public function catalogo(): void
    {
        $productos = $this->modeloProducto->obtenerTodos();
        $token = Seguridad::generarTokenCsrf();
        $this->renderizarVista('tienda/catalogo', ['productos' => $productos, 'token' => $token]);
    }

    public function comprar(int $idProducto): void
    {
        if (!$this->esPeticionPost() || !Seguridad::validarTokenCsrf($_POST['csrf_token'] ?? null)) {
            $this->redireccionar('tienda');
        }

        $cantidad = (int) ($_POST['cantidad'] ?? 1);
        $idCliente = (int) $_SESSION['id_cliente'];

        $resultado = $this->modeloPedido->comprarProducto($idCliente, $idProducto, $cantidad);

        $this->guardarMensaje($resultado['exito'] ? 'exito' : 'error', $resultado['mensaje']);
        $this->redireccionar('tienda');
    }

    public function misPedidos(): void
    {
        $idCliente = (int) $_SESSION['id_cliente'];
        $pedidos = $this->modeloPedido->obtenerPorCliente($idCliente);
        $this->renderizarVista('tienda/pedidos', ['pedidos' => $pedidos]);
    }
}
