<?php

class Usuario
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::obtenerInstancia()->obtenerConexion();
    }

    public function obtenerTodos(): array
    {
        $sentencia = $this->db->query(
            'SELECT id_usuario, nombre, apellido, email, rol, estado, fecha_creacion
             FROM usuarios ORDER BY fecha_creacion DESC'
        );
        return $sentencia->fetchAll();
    }

    public function buscarPorId(int $idUsuario): ?array
    {
        $sentencia = $this->db->prepare(
            'SELECT id_usuario, nombre, apellido, email, rol, estado
             FROM usuarios WHERE id_usuario = :id'
        );
        $sentencia->execute(['id' => $idUsuario]);
        $resultado = $sentencia->fetch();
        return $resultado ?: null;
    }

    public function buscarPorEmail(string $email): ?array
    {
        $sentencia = $this->db->prepare('SELECT * FROM usuarios WHERE email = :email');
        $sentencia->execute(['email' => $email]);
        $resultado = $sentencia->fetch();
        return $resultado ?: null;
    }

    public function crear(array $datos): bool
    {
        $sentencia = $this->db->prepare(
            'INSERT INTO usuarios (nombre, apellido, email, password_hash, rol)
             VALUES (:nombre, :apellido, :email, :passwordHash, :rol)'
        );

        return $sentencia->execute([
            'nombre'       => $datos['nombre'],
            'apellido'     => $datos['apellido'],
            'email'        => $datos['email'],
            'passwordHash' => password_hash($datos['password'], PASSWORD_BCRYPT, ['cost' => 12]),
            'rol'          => $datos['rol'] ?? 'almacenista',
        ]);
    }

    public function actualizar(int $idUsuario, array $datos): bool
    {
        $sentencia = $this->db->prepare(
            'UPDATE usuarios
             SET nombre = :nombre, apellido = :apellido, email = :email, rol = :rol
             WHERE id_usuario = :id'
        );

        return $sentencia->execute([
            'nombre'   => $datos['nombre'],
            'apellido' => $datos['apellido'],
            'email'    => $datos['email'],
            'rol'      => $datos['rol'],
            'id'       => $idUsuario,
        ]);
    }

    public function cambiarPassword(int $idUsuario, string $passwordNueva): bool
    {
        $sentencia = $this->db->prepare(
            'UPDATE usuarios SET password_hash = :passwordHash WHERE id_usuario = :id'
        );
        return $sentencia->execute([
            'passwordHash' => password_hash($passwordNueva, PASSWORD_BCRYPT, ['cost' => 12]),
            'id'           => $idUsuario,
        ]);
    }

    public function eliminar(int $idUsuario): bool
    {
        $sentencia = $this->db->prepare('DELETE FROM usuarios WHERE id_usuario = :id');
        return $sentencia->execute(['id' => $idUsuario]);
    }

    public function registrarIntentoFallido(int $idUsuario): void
    {
        $sentencia = $this->db->prepare(
            'UPDATE usuarios SET intentos_fallidos = intentos_fallidos + 1 WHERE id_usuario = :id'
        );
        $sentencia->execute(['id' => $idUsuario]);
    }

    public function bloquearCuenta(int $idUsuario, int $minutos): void
    {
        $sentencia = $this->db->prepare(
            'UPDATE usuarios SET bloqueado_hasta = DATE_ADD(NOW(), INTERVAL :minutos MINUTE)
             WHERE id_usuario = :id'
        );
        $sentencia->execute(['minutos' => $minutos, 'id' => $idUsuario]);
    }

    public function reiniciarIntentosFallidos(int $idUsuario): void
    {
        $sentencia = $this->db->prepare(
            'UPDATE usuarios SET intentos_fallidos = 0, bloqueado_hasta = NULL WHERE id_usuario = :id'
        );
        $sentencia->execute(['id' => $idUsuario]);
    }
}
