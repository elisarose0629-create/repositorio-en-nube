<?php


class Producto
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::obtenerInstancia()->obtenerConexion();
    }

    public function obtenerTodos(): array
    {
        $sentencia = $this->db->query(
            'SELECT p.id_producto, p.codigo_sku, p.nombre, p.descripcion, p.precio, p.stock,
                    p.stock_minimo, p.imagen, p.estado, c.nombre AS categoria
             FROM productos p
             LEFT JOIN categorias c ON c.id_categoria = p.id_categoria
             ORDER BY p.fecha_creacion DESC'
        );
        return $sentencia->fetchAll();
    }

    public function buscarPorId(int $idProducto): ?array
    {
        $sentencia = $this->db->prepare(
            'SELECT * FROM productos WHERE id_producto = :id'
        );
        $sentencia->execute(['id' => $idProducto]);
        $resultado = $sentencia->fetch();
        return $resultado ?: null;
    }

    public function crear(array $datos, ?int $idUsuario): bool
    {
        $sentencia = $this->db->prepare(
            'INSERT INTO productos
                (codigo_sku, nombre, descripcion, id_categoria, precio, stock, stock_minimo, imagen, id_usuario_creo)
             VALUES
                (:sku, :nombre, :descripcion, :categoria, :precio, :stock, :stockMinimo, :imagen, :idUsuario)'
        );

        return $sentencia->execute([
            'sku'         => $datos['codigo_sku'],
            'nombre'      => $datos['nombre'],
            'descripcion' => $datos['descripcion'] ?? '',
            'categoria'   => $datos['id_categoria'] ?: null,
            'precio'      => $datos['precio'],
            'stock'       => $datos['stock'] ?? 0,
            'stockMinimo' => $datos['stock_minimo'] ?? 5,
            'imagen'      => $datos['imagen'] ?? null,
            'idUsuario'   => $idUsuario,
        ]);
    }

    public function actualizar(int $idProducto, array $datos): bool
    {
        $sentencia = $this->db->prepare(
            'UPDATE productos
             SET codigo_sku = :sku, nombre = :nombre, descripcion = :descripcion,
                 id_categoria = :categoria, precio = :precio, stock = :stock,
                 stock_minimo = :stockMinimo
             WHERE id_producto = :id'
        );

        return $sentencia->execute([
            'sku'         => $datos['codigo_sku'],
            'nombre'      => $datos['nombre'],
            'descripcion' => $datos['descripcion'] ?? '',
            'categoria'   => $datos['id_categoria'] ?: null,
            'precio'      => $datos['precio'],
            'stock'       => $datos['stock'],
            'stockMinimo' => $datos['stock_minimo'],
            'id'          => $idProducto,
        ]);
    }

    public function eliminar(int $idProducto): bool
    {
        $sentencia = $this->db->prepare('DELETE FROM productos WHERE id_producto = :id');
        return $sentencia->execute(['id' => $idProducto]);
    }

    public function obtenerCategorias(): array
    {
        return $this->db->query('SELECT * FROM categorias ORDER BY nombre')->fetchAll();
    }

    public function registrarMovimiento(int $idProducto, string $tipo, int $cantidad, ?int $idUsuario, string $observacion = ''): bool
    {
        $this->db->beginTransaction();

        try {
            $operador = $tipo === 'salida' ? '-' : '+';
            $sentenciaStock = $this->db->prepare(
                "UPDATE productos SET stock = stock {$operador} :cantidad WHERE id_producto = :id"
            );
            $sentenciaStock->execute(['cantidad' => $cantidad, 'id' => $idProducto]);

            $sentenciaMovimiento = $this->db->prepare(
                'INSERT INTO movimientos_inventario (id_producto, tipo_movimiento, cantidad, id_usuario, observacion)
                 VALUES (:idProducto, :tipo, :cantidad, :idUsuario, :observacion)'
            );
            $sentenciaMovimiento->execute([
                'idProducto'  => $idProducto,
                'tipo'        => $tipo,
                'cantidad'    => $cantidad,
                'idUsuario'   => $idUsuario,
                'observacion' => $observacion,
            ]);

            $this->db->commit();
            return true;
        } catch (Exception $excepcion) {
            $this->db->rollBack();
            error_log('Error en movimiento de inventario: ' . $excepcion->getMessage());
            return false;
        }
    }
}
