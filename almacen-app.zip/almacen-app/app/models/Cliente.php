<?php

require_once APP_ROOT . '/app/core/Encryption.php';


class Cliente
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::obtenerInstancia()->obtenerConexion();
    }

    public function obtenerTodos(): array
    {
        $sentencia = $this->db->query(
            'SELECT id_cliente, nombre, apellido, email, telefono_cifrado, direccion_cifrada,
                    estado, fecha_registro
             FROM clientes ORDER BY fecha_registro DESC'
        );
        $clientes = $sentencia->fetchAll();

        foreach ($clientes as &$cliente) {
            $cliente['telefono'] = Encryption::descifrar($cliente['telefono_cifrado']);
            $cliente['direccion'] = Encryption::descifrar($cliente['direccion_cifrada']);
        }

        return $clientes;
    }

    public function buscarPorId(int $idCliente): ?array
    {
        $sentencia = $this->db->prepare('SELECT * FROM clientes WHERE id_cliente = :id');
        $sentencia->execute(['id' => $idCliente]);
        $cliente = $sentencia->fetch();

        if (!$cliente) {
            return null;
        }

        $cliente['telefono'] = Encryption::descifrar($cliente['telefono_cifrado']);
        $cliente['direccion'] = Encryption::descifrar($cliente['direccion_cifrada']);
        return $cliente;
    }

    public function buscarPorEmail(string $email): ?array
    {
        $sentencia = $this->db->prepare('SELECT * FROM clientes WHERE email = :email');
        $sentencia->execute(['email' => $email]);
        $resultado = $sentencia->fetch();
        return $resultado ?: null;
    }

    public function crear(array $datos): bool
    {
        $sentencia = $this->db->prepare(
            'INSERT INTO clientes (nombre, apellido, email, password_hash, telefono_cifrado, direccion_cifrada)
             VALUES (:nombre, :apellido, :email, :passwordHash, :telefono, :direccion)'
        );

        return $sentencia->execute([
            'nombre'       => $datos['nombre'],
            'apellido'     => $datos['apellido'],
            'email'        => $datos['email'],
            'passwordHash' => password_hash($datos['password'], PASSWORD_BCRYPT, ['cost' => 12]),
            'telefono'     => Encryption::cifrar($datos['telefono'] ?? ''),
            'direccion'    => Encryption::cifrar($datos['direccion'] ?? ''),
        ]);
    }

    public function actualizar(int $idCliente, array $datos): bool
    {
        $sentencia = $this->db->prepare(
            'UPDATE clientes
             SET nombre = :nombre, apellido = :apellido, email = :email,
                 telefono_cifrado = :telefono, direccion_cifrada = :direccion
             WHERE id_cliente = :id'
        );

        return $sentencia->execute([
            'nombre'    => $datos['nombre'],
            'apellido'  => $datos['apellido'],
            'email'     => $datos['email'],
            'telefono'  => Encryption::cifrar($datos['telefono'] ?? ''),
            'direccion' => Encryption::cifrar($datos['direccion'] ?? ''),
            'id'        => $idCliente,
        ]);
    }

    public function eliminar(int $idCliente): bool
    {
        $sentencia = $this->db->prepare('DELETE FROM clientes WHERE id_cliente = :id');
        return $sentencia->execute(['id' => $idCliente]);
    }

    public function registrarIntentoFallido(int $idCliente): void
    {
        $sentencia = $this->db->prepare(
            'UPDATE clientes SET intentos_fallidos = intentos_fallidos + 1 WHERE id_cliente = :id'
        );
        $sentencia->execute(['id' => $idCliente]);
    }

    public function reiniciarIntentosFallidos(int $idCliente): void
    {
        $sentencia = $this->db->prepare(
            'UPDATE clientes SET intentos_fallidos = 0, bloqueado_hasta = NULL WHERE id_cliente = :id'
        );
        $sentencia->execute(['id' => $idCliente]);
    }
}
