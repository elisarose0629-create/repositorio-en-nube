<?php


class Pedido
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::obtenerInstancia()->obtenerConexion();
    }

    public function comprarProducto(int $idCliente, int $idProducto, int $cantidad): array
    {
        if ($cantidad <= 0) {
            return ['exito' => false, 'mensaje' => 'La cantidad debe ser mayor a cero.'];
        }

        $this->db->beginTransaction();

        try {
            $sentenciaProducto = $this->db->prepare(
                'SELECT precio, stock FROM productos WHERE id_producto = :id FOR UPDATE'
            );
            $sentenciaProducto->execute(['id' => $idProducto]);
            $producto = $sentenciaProducto->fetch();

            if (!$producto) {
                $this->db->rollBack();
                return ['exito' => false, 'mensaje' => 'Producto no encontrado.'];
            }

            if ((int) $producto['stock'] < $cantidad) {
                $this->db->rollBack();
                return ['exito' => false, 'mensaje' => 'No hay suficiente stock disponible.'];
            }

            $subtotal = $producto['precio'] * $cantidad;

            $sentenciaPedido = $this->db->prepare(
                "INSERT INTO pedidos (id_cliente, total, estado) VALUES (:idCliente, :total, 'completado')"
            );
            $sentenciaPedido->execute(['idCliente' => $idCliente, 'total' => $subtotal]);
            $idPedido = (int) $this->db->lastInsertId();

            $sentenciaDetalle = $this->db->prepare(
                'INSERT INTO detalle_pedidos (id_pedido, id_producto, cantidad, precio_unitario, subtotal)
                 VALUES (:idPedido, :idProducto, :cantidad, :precio, :subtotal)'
            );
            $sentenciaDetalle->execute([
                'idPedido'   => $idPedido,
                'idProducto' => $idProducto,
                'cantidad'   => $cantidad,
                'precio'     => $producto['precio'],
                'subtotal'   => $subtotal,
            ]);

            $sentenciaStock = $this->db->prepare(
                'UPDATE productos SET stock = stock - :cantidad WHERE id_producto = :id'
            );
            $sentenciaStock->execute(['cantidad' => $cantidad, 'id' => $idProducto]);

            $sentenciaMovimiento = $this->db->prepare(
                "INSERT INTO movimientos_inventario (id_producto, tipo_movimiento, cantidad, id_usuario, observacion)
                 VALUES (:idProducto, 'salida', :cantidad, NULL, :observacion)"
            );
            $sentenciaMovimiento->execute([
                'idProducto'  => $idProducto,
                'cantidad'    => $cantidad,
                'observacion' => "Compra en tienda - pedido #{$idPedido} (cliente #{$idCliente})",
            ]);

            $this->db->commit();
            return ['exito' => true, 'mensaje' => 'Compra realizada correctamente.', 'id_pedido' => $idPedido];
        } catch (Exception $excepcion) {
            $this->db->rollBack();
            error_log('Error al procesar compra: ' . $excepcion->getMessage());
            return ['exito' => false, 'mensaje' => 'Ocurrió un error al procesar la compra.'];
        }
    }

    public function obtenerPorCliente(int $idCliente): array
    {
        $sentencia = $this->db->prepare(
            'SELECT id_pedido, total, estado, fecha_pedido
             FROM pedidos
             WHERE id_cliente = :idCliente
             ORDER BY fecha_pedido DESC'
        );
        $sentencia->execute(['idCliente' => $idCliente]);
        $pedidos = $sentencia->fetchAll();

        foreach ($pedidos as &$pedido) {
            $sentenciaDetalle = $this->db->prepare(
                'SELECT d.cantidad, d.precio_unitario, d.subtotal, pr.nombre AS producto
                 FROM detalle_pedidos d
                 JOIN productos pr ON pr.id_producto = d.id_producto
                 WHERE d.id_pedido = :idPedido'
            );
            $sentenciaDetalle->execute(['idPedido' => $pedido['id_pedido']]);
            $pedido['items'] = $sentenciaDetalle->fetchAll();
        }

        return $pedidos;
    }
}
