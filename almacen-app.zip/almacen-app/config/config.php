<?php
/**
 * Configuración global de la aplicación.
 * Ajustar estos valores según el entorno (desarrollo / producción).
 */

// --- Base de datos ---
define('DB_HOST', 'localhost');
define('DB_NAME', 'almacen_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// --- Seguridad ---
// Clave usada por la clase Encryption para cifrar datos sensibles (AES-256-CBC).
// En producción esta clave DEBE cargarse desde una variable de entorno,
// nunca dejarla escrita en el código fuente.
define('APP_ENCRYPTION_KEY', getenv('APP_ENCRYPTION_KEY') ?: 'CAMBIAR_ESTA_CLAVE_EN_PRODUCCION_32B');

// Tiempo de vida de la sesión en segundos (30 minutos)
define('SESSION_LIFETIME', 1800);

// Máximo de intentos fallidos de login antes de bloquear la cuenta
define('MAX_INTENTOS_LOGIN', 5);
define('MINUTOS_BLOQUEO', 15);

// --- Rutas base ---
define('BASE_URL', '/almacen-app/public');
define('APP_ROOT', dirname(__DIR__));

// --- Zona horaria ---
date_default_timezone_set('America/Panama');

// --- Cabeceras de seguridad básicas ---
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("Referrer-Policy: strict-origin-when-cross-origin");
// Forzar HTTPS en producción (descomentar cuando exista certificado válido)
// header("Strict-Transport-Security: max-age=63072000; includeSubDomains");

// --- Configuración de sesión segura ---
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_samesite', 'Strict');
// ini_set('session.cookie_secure', 1); // activar cuando se sirva por HTTPS

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
