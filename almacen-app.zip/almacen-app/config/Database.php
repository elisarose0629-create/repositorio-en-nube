<?php

/**
 * Clase Database
 * Maneja la conexión a la base de datos mediante PDO utilizando
 * el patrón Singleton para evitar múltiples conexiones simultáneas.
 * Todas las consultas del sistema deben usar sentencias preparadas
 * a través de esta clase para prevenir inyección SQL.
 */
class Database
{
    private static ?Database $instancia = null;
    private PDO $conexion;

    private function __construct()
    {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

        $opciones = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false, // usa sentencias preparadas reales del motor
        ];

        try {
            $this->conexion = new PDO($dsn, DB_USER, DB_PASS, $opciones);
        } catch (PDOException $excepcion) {
            // Nunca mostrar detalles de la excepción real al usuario final
            error_log('Error de conexión a BD: ' . $excepcion->getMessage());
            die('No fue posible conectar con la base de datos. Intente más tarde.');
        }
    }

    public static function obtenerInstancia(): Database
    {
        if (self::$instancia === null) {
            self::$instancia = new self();
        }
        return self::$instancia;
    }

    public function obtenerConexion(): PDO
    {
        return $this->conexion;
    }

    // Evitar clonación e instanciación externa (Singleton)
    private function __clone() {}
    public function __wakeup() {}
}
