<?php

/**
 * Front Controller
 * Único punto de entrada de la aplicación. Enruta las peticiones
 * hacia el controlador y método (acción) correspondientes.
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/Database.php';
require_once APP_ROOT . '/app/core/Controller.php';
require_once APP_ROOT . '/app/core/Seguridad.php';

// Control de expiración de sesión por inactividad
if (!empty($_SESSION['autenticado'])) {
    if ((time() - ($_SESSION['ultima_actividad'] ?? 0)) > SESSION_LIFETIME) {
        $_SESSION = [];
        session_destroy();
        header('Location: ' . BASE_URL . '/login');
        exit;
    }
    $_SESSION['ultima_actividad'] = time();
}

// Se obtiene la ruta solicitada, por ejemplo: /productos/editar/3
$rutaSolicitada = $_GET['ruta'] ?? 'login';
$segmentos = array_values(array_filter(explode('/', trim($rutaSolicitada, '/'))));

$mapaRutas = [
    ''            => ['AuthController', 'mostrarLogin'],
    'login'       => ['AuthController', 'mostrarLogin'],
    'auth-login'  => ['AuthController', 'procesarLogin'],
    'registro'    => ['AuthController', 'mostrarRegistro'],
    'auth-registro' => ['AuthController', 'procesarRegistro'],
    'logout'      => ['AuthController', 'cerrarSesion'],

    'tienda'          => ['TiendaController', 'catalogo'],
    'tienda-comprar'  => ['TiendaController', 'comprar'],
    'tienda-pedidos'  => ['TiendaController', 'misPedidos'],

    'productos'          => ['ProductoController', 'listar'],
    'productos-crear'    => ['ProductoController', 'mostrarFormularioCrear'],
    'productos-guardar'  => ['ProductoController', 'crear'],
    'productos-editar'   => ['ProductoController', 'mostrarFormularioEditar'],
    'productos-actualizar' => ['ProductoController', 'actualizar'],
    'productos-eliminar' => ['ProductoController', 'eliminar'],

    'usuarios'           => ['UsuarioController', 'listar'],
    'usuarios-crear'     => ['UsuarioController', 'mostrarFormularioCrear'],
    'usuarios-guardar'   => ['UsuarioController', 'crear'],
    'usuarios-editar'    => ['UsuarioController', 'mostrarFormularioEditar'],
    'usuarios-actualizar' => ['UsuarioController', 'actualizar'],
    'usuarios-eliminar'  => ['UsuarioController', 'eliminar'],

    'clientes'           => ['ClienteController', 'listar'],
    'clientes-editar'    => ['ClienteController', 'mostrarFormularioEditar'],
    'clientes-actualizar' => ['ClienteController', 'actualizar'],
    'clientes-eliminar'  => ['ClienteController', 'eliminar'],
];

$accionPrincipal = $segmentos[0] ?? 'login';
$subAccion = $segmentos[1] ?? null;
$idParametro = isset($segmentos[2]) ? (int) $segmentos[2] : null;

$clave = $subAccion ? $accionPrincipal . '-' . $subAccion : $accionPrincipal;

if (!array_key_exists($clave, $mapaRutas)) {
    http_response_code(404);
    echo '404 - Página no encontrada';
    exit;
}

[$nombreControlador, $nombreMetodo] = $mapaRutas[$clave];

$rutaArchivoControlador = APP_ROOT . '/app/controllers/' . $nombreControlador . '.php';
if (!file_exists($rutaArchivoControlador)) {
    http_response_code(500);
    echo 'Controlador no encontrado.';
    exit;
}
require_once $rutaArchivoControlador;

$controlador = new $nombreControlador();

if ($idParametro !== null) {
    $controlador->$nombreMetodo($idParametro);
} else {
    $controlador->$nombreMetodo();
}
