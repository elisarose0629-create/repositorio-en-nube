/**
 * script.js
 * Validaciones básicas en el lado del cliente. Estas validaciones
 * son un complemento de usabilidad; la validación real y obligatoria
 * de seguridad siempre se realiza en el servidor (PHP).
 */

document.addEventListener('DOMContentLoaded', function () {
    inicializarValidacionFormularios();
    inicializarCierreAlertas();
});

function inicializarValidacionFormularios() {
    const formularios = document.querySelectorAll('.formulario');

    formularios.forEach(function (formulario) {
        formulario.addEventListener('submit', function (evento) {
            const passwordCampo = formulario.querySelector('#password');
            const confirmarCampo = formulario.querySelector('#confirmar_password');

            if (passwordCampo && confirmarCampo && passwordCampo.value.length > 0) {
                if (passwordCampo.value !== confirmarCampo.value) {
                    evento.preventDefault();
                    mostrarError(confirmarCampo, 'Las contraseñas no coinciden.');
                    return;
                }
            }

            const camposRequeridos = formulario.querySelectorAll('[required]');
            let formularioValido = true;

            camposRequeridos.forEach(function (campo) {
                if (!campo.value.trim()) {
                    formularioValido = false;
                    mostrarError(campo, 'Este campo es obligatorio.');
                }
            });

            if (!formularioValido) {
                evento.preventDefault();
            }
        });
    });
}

function mostrarError(campo, mensaje) {
    campo.style.borderColor = '#c0392b';
    campo.setCustomValidity(mensaje);
    campo.reportValidity();

    campo.addEventListener('input', function limpiar() {
        campo.style.borderColor = '';
        campo.setCustomValidity('');
        campo.removeEventListener('input', limpiar);
    });
}

function inicializarCierreAlertas() {
    const alertas = document.querySelectorAll('.alerta');
    alertas.forEach(function (alerta) {
        setTimeout(function () {
            alerta.style.transition = 'opacity 0.5s ease';
            alerta.style.opacity = '0';
            setTimeout(function () {
                alerta.remove();
            }, 500);
        }, 5000);
    });
}
