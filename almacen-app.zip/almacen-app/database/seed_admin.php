<?php
/**
 * Script de una sola ejecución para crear el primer usuario
 * administrador del sistema.
 *
 * Uso desde la línea de comandos (dentro de la carpeta database/):
 *   php seed_admin.php "Nombre" "Apellido" "correo@ejemplo.com" "ContraseñaSegura#1"
 *
 * IMPORTANTE: eliminar o proteger este archivo después de usarlo,
 * ya que crea cuentas con rol de administrador.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../app/core/Seguridad.php';
require_once __DIR__ . '/../app/models/Usuario.php';

if (php_sapi_name() !== 'cli') {
    die("Este script solo puede ejecutarse desde la línea de comandos por seguridad.\n");
}

[$scriptNombre, $nombre, $apellido, $email, $password] = array_pad($argv, 5, null);

if (!$nombre || !$apellido || !$email || !$password) {
    echo "Uso: php seed_admin.php \"Nombre\" \"Apellido\" \"correo@ejemplo.com\" \"ContraseñaSegura#1\"\n";
    exit(1);
}

if (!Seguridad::validarEmail($email)) {
    die("El correo electrónico no es válido.\n");
}

if (!Seguridad::passwordEsSegura($password)) {
    die("La contraseña debe tener mínimo 8 caracteres, una mayúscula, una minúscula y un número.\n");
}

$modeloUsuario = new Usuario();

if ($modeloUsuario->buscarPorEmail($email)) {
    die("Ya existe un usuario registrado con ese correo.\n");
}

$creado = $modeloUsuario->crear([
    'nombre'   => $nombre,
    'apellido' => $apellido,
    'email'    => $email,
    'password' => $password,
    'rol'      => 'administrador',
]);

if ($creado) {
    echo "✅ Usuario administrador creado correctamente: {$email}\n";
} else {
    echo "❌ Ocurrió un error al crear el usuario.\n";
}
