-- ============================================================
-- Base de datos: Sistema de Gestión de Almacén
-- Motor: MySQL 8.0+ / MariaDB 10.4+
-- Codificación: utf8mb4
-- ============================================================

CREATE DATABASE IF NOT EXISTS almacen_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE almacen_db;

-- ------------------------------------------------------------
-- Tabla: usuarios (personal interno / administradores del sistema)
-- ------------------------------------------------------------
CREATE TABLE usuarios (
    id_usuario        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre            VARCHAR(80)  NOT NULL,
    apellido          VARCHAR(80)  NOT NULL,
    email             VARCHAR(150) NOT NULL UNIQUE,
    password_hash     VARCHAR(255) NOT NULL,
    rol               ENUM('administrador','almacenista','vendedor') NOT NULL DEFAULT 'almacenista',
    estado            TINYINT(1)   NOT NULL DEFAULT 1,
    token_sesion      VARCHAR(255) NULL,
    intentos_fallidos INT UNSIGNED NOT NULL DEFAULT 0,
    bloqueado_hasta   DATETIME NULL,
    fecha_creacion    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabla: clientes (usuarios de la tienda / login público)
-- Los campos sensibles (telefono, direccion) se guardan cifrados
-- con AES-256-CBC desde la capa de aplicación (ver Encryption.php)
-- ------------------------------------------------------------
CREATE TABLE clientes (
    id_cliente        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre            VARCHAR(80)  NOT NULL,
    apellido          VARCHAR(80)  NOT NULL,
    email             VARCHAR(150) NOT NULL UNIQUE,
    password_hash     VARCHAR(255) NOT NULL,
    telefono_cifrado  VARCHAR(255) NULL,
    direccion_cifrada TEXT NULL,
    estado            TINYINT(1)   NOT NULL DEFAULT 1,
    token_sesion      VARCHAR(255) NULL,
    intentos_fallidos INT UNSIGNED NOT NULL DEFAULT 0,
    bloqueado_hasta   DATETIME NULL,
    fecha_registro    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabla: categorias
-- ------------------------------------------------------------
CREATE TABLE categorias (
    id_categoria   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre         VARCHAR(100) NOT NULL UNIQUE,
    descripcion    VARCHAR(255) NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabla: productos
-- ------------------------------------------------------------
CREATE TABLE productos (
    id_producto     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    codigo_sku      VARCHAR(40)  NOT NULL UNIQUE,
    nombre          VARCHAR(150) NOT NULL,
    descripcion     TEXT NULL,
    id_categoria    INT UNSIGNED NULL,
    precio          DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    stock           INT NOT NULL DEFAULT 0,
    stock_minimo    INT NOT NULL DEFAULT 5,
    imagen          VARCHAR(255) NULL,
    estado          TINYINT(1) NOT NULL DEFAULT 1,
    id_usuario_creo INT UNSIGNED NULL,
    fecha_creacion  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_producto_categoria FOREIGN KEY (id_categoria)
        REFERENCES categorias(id_categoria) ON DELETE SET NULL,
    CONSTRAINT fk_producto_usuario FOREIGN KEY (id_usuario_creo)
        REFERENCES usuarios(id_usuario) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabla: movimientos_inventario (entradas / salidas de almacén)
-- ------------------------------------------------------------
CREATE TABLE movimientos_inventario (
    id_movimiento   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_producto     INT UNSIGNED NOT NULL,
    tipo_movimiento ENUM('entrada','salida','ajuste') NOT NULL,
    cantidad        INT NOT NULL,
    id_usuario      INT UNSIGNED NULL,
    observacion     VARCHAR(255) NULL,
    fecha_movimiento DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_mov_producto FOREIGN KEY (id_producto)
        REFERENCES productos(id_producto) ON DELETE CASCADE,
    CONSTRAINT fk_mov_usuario FOREIGN KEY (id_usuario)
        REFERENCES usuarios(id_usuario) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabla: pedidos (encabezado de cada compra realizada por un cliente)
-- ------------------------------------------------------------
CREATE TABLE pedidos (
    id_pedido    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_cliente   INT UNSIGNED NOT NULL,
    total        DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    estado       ENUM('completado','cancelado') NOT NULL DEFAULT 'completado',
    fecha_pedido DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_pedido_cliente FOREIGN KEY (id_cliente)
        REFERENCES clientes(id_cliente) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabla: detalle_pedidos (productos incluidos en cada pedido)
-- ------------------------------------------------------------
CREATE TABLE detalle_pedidos (
    id_detalle      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_pedido       INT UNSIGNED NOT NULL,
    id_producto     INT UNSIGNED NOT NULL,
    cantidad        INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    subtotal        DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_detalle_pedido FOREIGN KEY (id_pedido)
        REFERENCES pedidos(id_pedido) ON DELETE CASCADE,
    CONSTRAINT fk_detalle_producto FOREIGN KEY (id_producto)
        REFERENCES productos(id_producto)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Datos de ejemplo
-- ------------------------------------------------------------
INSERT INTO categorias (nombre, descripcion) VALUES
('Electrónica', 'Dispositivos y accesorios electrónicos'),
('Oficina', 'Artículos de papelería y oficina'),
('Limpieza', 'Productos de aseo e higiene');

-- Usuario administrador de ejemplo (password: Admin#2026 -> se debe generar con password_hash)
-- El hash real se genera desde PHP al ejecutar el script de instalación (ver /database/seed.php)
