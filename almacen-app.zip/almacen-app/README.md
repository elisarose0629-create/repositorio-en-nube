# AlmacénApp — Sistema de Gestión de Almacén (PHP OOP + PDO)

Sistema web para la gestión de inventario de una tienda, con inicio de
sesión y registro tanto para clientes como para personal interno
(administradores, almacenistas y vendedores), y CRUD completo de
usuarios, clientes y productos.

## Estructura del proyecto (patrón MVC)

```
almacen-app/
├── config/
│   ├── config.php        # Configuración global y cabeceras de seguridad
│   └── Database.php      # Conexión PDO (Singleton)
├── app/
│   ├── core/
│   │   ├── Controller.php    # Controlador base
│   │   ├── Encryption.php    # Cifrado AES-256-CBC de datos sensibles
│   │   └── Seguridad.php     # CSRF, sanitización, validaciones
│   ├── models/
│   │   ├── Usuario.php
│   │   ├── Cliente.php
│   │   └── Producto.php
│   ├── controllers/
│   │   ├── AuthController.php
│   │   ├── UsuarioController.php
│   │   ├── ClienteController.php
│   │   ├── ProductoController.php
│   │   └── TiendaController.php
│   └── views/
│       ├── layout/ (header.php, footer.php)
│       ├── auth/ (login.php, registro.php)
│       ├── usuarios/, clientes/, productos/, tienda/
├── public/                # Document root del servidor web
│   ├── index.php          # Front Controller (único punto de entrada)
│   ├── .htaccess           # Reescritura de URLs amigables
│   ├── css/style.css
│   ├── js/script.js
│   └── img/favicon.png
├── database/
│   └── almacen.sql        # Script de creación de la base de datos
└── README.md
```

## Requisitos

- PHP 8.1 o superior, con extensiones `pdo_mysql` y `openssl` habilitadas.
- MySQL 8.0+ o MariaDB 10.4+.
- Apache con `mod_rewrite` habilitado (o Nginx equivalente).

## Instalación

1. Copiar la carpeta `almacen-app` dentro del document root de su
   servidor (ej. `htdocs/`, `www/`).
2. Importar la base de datos:
   ```bash
   mysql -u root -p < database/almacen.sql
   ```
3. Editar `config/config.php` con las credenciales reales de la base
   de datos y una clave de cifrado propia (`APP_ENCRYPTION_KEY`),
   idealmente definida como variable de entorno del servidor.
4. Configurar el *document root* del sitio hacia la carpeta `public/`
   (así el código de `app/` y `config/` nunca queda expuesto
   directamente al navegador).
5. Crear el primer usuario administrador ejecutando, por ejemplo,
   un pequeño script una sola vez con:
   ```php
   password_hash('SuClaveSegura#1', PASSWORD_BCRYPT);
   ```
   e insertando el resultado directamente en la tabla `usuarios`.
6. Acceder a `http://localhost/login`.

## Buenas prácticas de seguridad implementadas

- **Prevención de inyección SQL:** todas las consultas usan PDO con
  sentencias preparadas (`prepare()` + parámetros nombrados), nunca
  concatenación de cadenas.
- **Contraseñas:** se almacenan únicamente como hash (`password_hash`
  con BCRYPT, costo 12), nunca en texto plano.
- **Cifrado de datos sensibles:** teléfono y dirección de los
  clientes se cifran con AES-256-CBC (clase `Encryption`) antes de
  guardarse en la base de datos.
- **CSRF:** todo formulario incluye un token de sesión validado en
  el servidor antes de procesar la petición.
- **Sanitización de entradas:** toda entrada de usuario pasa por
  `Seguridad::limpiarCadena()` (elimina etiquetas HTML y escapa
  caracteres especiales) antes de usarse.
- **Bloqueo por intentos fallidos:** tras varios intentos de login
  incorrectos, la cuenta se bloquea temporalmente.
- **Cookies de sesión seguras:** `HttpOnly`, `SameSite=Strict` y
  expiración por inactividad.
- **Cabeceras HTTP de seguridad:** `X-Frame-Options`,
  `X-Content-Type-Options`, `Referrer-Policy`.
- **HTTPS:** se recomienda servir la aplicación bajo TLS/HTTPS para
  que el cifrado en tránsito complemente el cifrado de aplicación.

## Convenciones de codificación

- Clases en `PascalCase` (`Usuario`, `ProductoController`).
- Métodos y variables en `camelCase` (`buscarPorEmail`,
  `passwordHash`).
- Un archivo por clase, con `namespace` implícito por carpeta.
- Todo acceso a datos pasa por un Modelo; ningún controlador ejecuta
  SQL directamente.
